$(document).ready(function(){
    $("#login-title1").click(function(){
        $("#login-show").show();
        $("#register-show").hide();
    });

    $("#register-title1").click(function(){
        $("#login-show").hide();
        $("#register-show").show();
    });
    $("#login-title2").click(function(){
        $("#login-show").show();
        $("#register-show").hide();
    });

    $("#register-title2").click(function(){
        $("#login-show").hide();
        $("#register-show").show();
    });
})