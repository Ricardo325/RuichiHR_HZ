$(document).ready(function(){
    var c=false;
    $("#menu-sub").click(function(){
         $("#vertify-sub").slideToggle();
         $("#vertify-sub a:first-child").toggleClass("active");
         
         if(c == false){
            $("#vertify-sub .labelToggle").addClass("fa-window-minimize");
            $("#vertify-sub .labelToggle").removeClass("fa-plus"); 
            c=true;
         }
         else{
            $("#vertify-sub .labelToggle").addClass("fa-plus");
            $("#vertify-sub .labelToggle").removeClass("fa-window-minimize"); 
            c=false;
         }

    })
})

